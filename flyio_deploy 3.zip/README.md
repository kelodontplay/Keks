# Fly.io Deployment

This is a minimal example to deploy a Debian-based bash environment on Fly.io.

## Files

- Dockerfile: runs Debian with bash
- fly.toml: basic app configuration

## Deploy Steps

1. Push this to GitHub
2. Connect the repo on Fly.io
3. Deploy!